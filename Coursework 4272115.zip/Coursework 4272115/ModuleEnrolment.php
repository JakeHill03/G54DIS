﻿<!DOCTYPE html>
<?php include('server.php') ?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<?php
  session_start();
  // Don't allow somebody who hasn't enrolled to access the page, redirect to the login page
  if (!isset($_SESSION['StudentID'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['StudnetID']);
  	header("location: login.php");
  }
?>
<head>
    <meta charset="utf-8" />
    <title>UoN Database</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <h2>Register Module</h2>
    </div>
	<!-- creating a module enrolment form-->
    <form method="post" action="ModuleEnrolment.php">
        <?php include('errors.php'); ?>
        <div class="input-group">
            <label>Student ID</label>
            <input type="int" name="StudID" value="<?php echo $StudID; ?>">
        </div>
        <div class="input-group">
            <label>Module ID</label>
            <input type="text" name="ModID" value="<?php echo $ModID; ?>">
        </div>
        <div class="input-group">
            <button type="submit" class="btn" name="reg_in_module">Register</button>
        </div>
        <p>
            If no errors are returned you have enrolled in the module.
        </p>
        <p>
            Return to home page? <a href="index.php">Return</a>
        </p>
    </form>
</body>
</html>