﻿<!DOCTYPE html>
<?php include('server.php') ?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>UoN Database</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <h2>Register</h2>
    </div>
	<!-- create a form so that new students can register-->
    <form method="post" action="register.php">
        <?php include('errors.php'); ?>
		<div class="input-group">
            <label>StudentID</label>
            <input type="int" name="StudentID" value="<?php echo $StudentID; ?>">
        </div>
		<div class="input-group">
            <label>First Name</label>
            <input type="text" name="FirstNames" value="<?php echo $FirstNames; ?>">
        </div>
		<div class="input-group">
            <label>Surname</label>
            <input type="text" name="Surname" value="<?php echo $Surname; ?>">
        </div>
		<div class="input-group">
            <label>Course</label>
            <input type="text" name="Course" value="<?php echo $Course; ?>">
        </div>
		<div class="input-group">
            <label>Address</label>
            <input type="text" name="Address" value="<?php echo $Address; ?>">
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password_1">
        </div>
        <div class="input-group">
            <label>Confirm password</label>
            <input type="password" name="password_2">
        </div>
        <div class="input-group">
            <button type="submit" class="btn" name="reg_user">Register</button>
        </div>
        <p>
            Already enrolled? <a href="login.php">Sign in</a>
        </p>
    </form>
</body>
</html>