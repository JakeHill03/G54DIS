﻿<!DOCTYPE html>
<?php include('server.php') ?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<?php
  session_start();
  //if the student hasnt already logged in redirect them to the login page
  if (!isset($_SESSION['StudentID'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['StudnetID']);
  	header("location: login.php");
  }
?>
<head> 
<!-- references back to the css file -->
    <meta charset="utf-8" />
    <title>UoN Database</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <h2>Register Module</h2>
    </div>
	<!-- Create a form so modules can be registered-->
    <form method="post" action="RegisterModules.php">
        <?php include('errors.php'); ?>
        <div class="input-group">
            <label>ModuleID</label>
            <input type="int" name="ModuleID" value="<?php echo $ModuleID; ?>">
        </div>
        <div class="input-group">
            <label>Module Name</label>
            <input type="text" name="ModuleName" value="<?php echo $ModuleName; ?>">
        </div>
        <div class="input-group">
            <label>Module Description</label>
            <input type="text" name="ModuleDescription" value="<?php echo $ModuleDescription; ?>">
        </div>
        <div class="input-group">
            <label>Lecture room and day of lectures</label>
            <input type="text" name="LectureRoom" value="<?php echo $LectureRoom; ?>">
        </div>
        <div class="input-group">
            <label>Lecture Time takes 00:00 format</label>
            <input type="text" name="LectureTime" value="<?php echo $LectureTime; ?>">
        </div>
        <div class="input-group">
            <button type="submit" class="btn" name="reg_module">Register</button>
        </div>
        <p>
            If no errors are returned Module has been created.
        </p>
        <p>
            Return to home page? <a href="index.php">Return</a>
        </p>
    </form>
</body>
</html>