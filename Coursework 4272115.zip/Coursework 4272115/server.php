﻿<?php
session_start();
// This page is linked to all the other pages by being referenced at the top. This means that everypage has access to the php within this document
// initializing variables
$StudentID = "";
$errors = array();
$servername = "mysql.cs.nott.ac.uk";
$dbusername = "styjth";
$dbpassword = "Rugby#1";
$dbname = "styjth";

// connect to the database
$db = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

if ($db->connect_error) {
    die("connection failed: " . $db->connect_error);
    }
    echo "connected successfully";

// Register Student
if (isset($_POST['reg_user'])) {
  
  $StudentID = mysqli_real_escape_string($db, $_POST['StudentID']);
  $FirstNames = mysqli_real_escape_string($db, $_POST['FirstNames']);
  $Surname = mysqli_real_escape_string($db, $_POST['Surname']);
  $Course = mysqli_real_escape_string($db, $_POST['Course']);
  $Address = mysqli_real_escape_string($db, $_POST['Address']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

  if (empty($StudentID)) { array_push($errors, "StudentID is required"); }
  if (empty($FirstNames)) { array_push($errors, "FirstNames is required"); }
  if (empty($Surname)) { array_push($errors, "Surname is required"); }
  if (empty($Course)) { array_push($errors, "Course is required"); }
  if (empty($Address)) { array_push($errors, "Address is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure
  // a user does not already exist with the same StudentID
  $user_check_query = "SELECT * FROM Students WHERE StudentID='.$StudentID.'";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if Student exists
    if ($user['StudentID'] === $StudentID) {
      array_push($errors, "StudentID already exists");
    }
  }

  //Check for errors then insert into database if there isn't any
  if (count($errors) == 0) {
  	$password =md5($password_1);

  	$query = "INSERT INTO Students (StudentID, FirstNames, Surname, Course, Address, Password)
  			  VALUES('$StudentID', '$FirstNames', '$Surname', '$Course', '$Address', '$password')";
  	mysqli_query($db, $query);
  	$_SESSION['StudentID'] = $StudentID;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}
// Register module
if (isset($_POST['reg_module'])) {
  
  $ModuleID = mysqli_real_escape_string($db, $_POST['ModuleID']);
  $ModuleName = mysqli_real_escape_string($db, $_POST['ModuleName']);
  $ModuleDescription = mysqli_real_escape_string($db, $_POST['ModuleDescription']);
  $LectureRoom = mysqli_real_escape_string($db, $_POST['LectureRoom']);
  $LectureTime = mysqli_real_escape_string($db, $_POST['LectureTime']);
  
  if (empty($ModuleID)) { array_push($errors, "ModuleID is required"); }
  if (empty($ModuleName)) { array_push($errors, "ModuleName is required"); }
  if (empty($ModuleDescription)) { array_push($errors, "ModuleDescription is required"); }
  if (empty($LectureRoom)) { array_push($errors, "LectureRoom is required"); }
  if (empty($LectureTime)) { array_push($errors, "LectureTime is required"); }
  }

  // check the database to make sure
  // a module does not already exist with the same ModuleID
  $user_check_query = "SELECT * FROM Modules WHERE ModuleID='.$ModuleID.'";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if Student exists
    if ($user['ModuleID'] === $ModuleID) {
      array_push($errors, "ModuleID already exists");
    }
  }

  
  if (count($errors) == 0) {

  	$query = "INSERT INTO Modules (ModuleID, ModuleName, ModuleDescription, LectureRoom, LectureTime)
  			  VALUES('$ModuleID', '$ModuleName', '$ModuleDescription', '$LectureRoom', '$LectureTime')";
  	mysqli_query($db, $query);
  
}
// Register studnet into module
if (isset($_POST['reg_in_module'])) {
  
  $StudID = mysqli_real_escape_string($db, $_POST['StudID']);
  $ModID = mysqli_real_escape_string($db, $_POST['ModID']);
 
  
  if (empty($StudID)) { array_push($errors, "Student ID is required"); }
  if (empty($ModID)) { array_push($errors, "Module ID is required"); }
  }

  // first check the database to make sure
  // a that the student isn't alreay enrolled in the module'
  $user_check_query = "SELECT * FROM Modules WHERE (StudID,ModID)='.$StudID.' AND '.$ModID.'";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if Student exists
    if ($user['(StudID,ModID'] === $StudID AND $ModID) {
      array_push($errors, "You've already enrolled in this module");
    }
  }

  
  if (count($errors) == 0) {

  	$query = "INSERT INTO Enrolment (StudID, ModID)
  			  VALUES('$StudID', '$ModID')";
  	mysqli_query($db, $query);
  
}
//login
if (isset($_POST['login_user'])) {
  $StudentID = mysqli_real_escape_string($db, $_POST['StudentID']);
  $password = mysqli_real_escape_string($db, $_POST['Password']);

  if (empty($StudentID)) {
  	array_push($errors, "StudentID is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password =md5($password);
  	$query = "SELECT * FROM Students WHERE StudentID='$StudentID' AND Password='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['StudentID'] = $StudentID;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}
//Tried to make it so that the users credentials when asked for would show on the index/home php page.
if (isset($_POST['login_user'])) {
	$StudentID = mysqli_real_escape_string($db, $_POST['StudentID']);
	$sql = "SELECT StudentID, FirstNames, Surname, Course FROM Students WHERE StudentID='$StudentID'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
    
	 while($row = $result->fetch_assoc()) {
        echo "<br> id: ". $row["StudentID"]. " - Name: ". $row["FirstNames"]. " " . $row["Surname"] . "-Course: ". $row["Course"]. "<br>";
     }
	} else {
		echo "0 results";
}}	
?>
