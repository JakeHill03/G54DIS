﻿<!DOCTYPE html>
<?php include('server.php') ?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>UoN Database</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <h2>Login</h2>
    </div>

    <form method="post" action="login.php">
        <?php include('errors.php'); ?>
        <div class="input-group">
            <label>StudentID</label>
            <input type="text" name="StudentID">
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="Password">
        </div>
        <div class="input-group">
            <button type="submit" class="btn" name="login_user">Login</button>
        </div>
        <p>
            Haven't enrolled? <a href="register.php">Enrol</a>
        </p>
    </form>
</body>
</html>