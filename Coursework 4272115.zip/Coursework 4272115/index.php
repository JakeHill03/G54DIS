﻿<?php include('server.php') ?>
<?php
  session_start();

  if (!isset($_SESSION['StudentID'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['StudnetID']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <div class="header">
        <h2>Home Page</h2>
    </div>
    <div class="content">
        <!-- notification message -->
        <?php if (isset($_SESSION['success'])) : ?>
        <div class="error success">
            <h3>
                <?php
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </h3>
        </div>
        <?php endif ?>
		<div>
        <!-- logged in user information -->
        <?php  if (isset($_SESSION['StudentID'])) : ?>
        <p>Welcome <strong><?php echo $_SESSION['StudentID']; ?></strong></p>
		</div>
		<form method="post" action="index.php">
        <?php include('errors.php'); ?>
        <div class="input-group">
            <label>Check Credentials</label>
            <input type="text" name="Check_Credentials" value="<?php echo $StudentID; ?>">
        </div>
        <div class="input-group">
            <button type="submit" class="btn" name="index.php">Search</button>
        </div>
    </form>
		<div>
		<p> <a href="RegisterModules.php" style="color: red;">Insert new modules</a> </p>
		<div>
		<div>
		<p> <a href="ModuleEnrolment.php" style="color: red;">Choose modules</a> </p>
		<div>
        <p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
		</div>
        <?php endif ?>
    

</body>
</html>